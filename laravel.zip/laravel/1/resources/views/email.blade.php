@extends('tema.master')
@section('title', 'email')
 
@section('intro-header')
  <!-- Header -->
  <header class="intro-header text-white" style="background: url('{{ asset
 
('images/contact-bg.jpg') }}') no-repeat center center;">
    <div class="container text-center">
      <h1>email</h1>
      
    </div>
  </header>
  <!-- END : Header -->

 
@section('content')
<body class="intro-header text-white" style="background: url('{{ asset
 
 ('images/home-bg.jpg') }}') no-repeat center center;">
<h2>claramaharanymaharany941@gmail.com </h2>

<h2>yulianaverucha@gmail.com </h2>
<h2> email  </h2>
@endsection