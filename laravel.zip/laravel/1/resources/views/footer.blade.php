    <!-- Footer -->
    <footer class="py-5 bg-info">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Belajar Koding 2018</p>
      </div>
    </footer>
    <!-- END : Footer -->
 
    <!-- Bootstrap core JavaScript -->
    <script src="{{ asset('belajar_laravel/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('belajar_laravel/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  </body>
</html>