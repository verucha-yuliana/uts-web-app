<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
 <div class="container">
 <a class="navbar-brand" href="http://127.0.0.1:8000/">Home</a>
 <button class="navbar-toggler" type="button" datatoggle="collapse" data-target="#navbarTogglerDemo02" ariacont.rols="navbarTogglerDemo02" aria-expanded="false" arialabel="Toggle navigation">
 <span class="navbar-toggler-icon"></span>
 </button>

 <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
 <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
 <li class="nav-item active">
 <a class="nav-link" href="http://127.0.0.1:8000/uts">UTS</a>
 </li>
 <li class="nav-item">
 <a class="nav-link" href="http://127.0.0.1:8000/about">about</a>
 </li>
 <a class="nav-link" href="http://127.0.0.1:8000/contact">contact</a>
 </li>
 <li class="nav-item">
 <a class="nav-link" href="http://127.0.0.1:8000/email">email</a>
 <li class="nav-item">
 <a class="nav-link" href="http://127.0.0.1:8000/form">form</a>
 </ul>
 <form class="form-inline my-2 my-lg-0">
 <input class="form-control mr-sm2" type="search" placeholder="Mau Cari Apa??">
 <button class="btn btn-outline-success my-2 my-sm0" type="submit">Search</button>
 </form>
 </div>
 </div>

 </nav>