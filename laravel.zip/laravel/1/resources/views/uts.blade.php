@extends('tema.master')
@section('title', 'soal uts')
 
@section('intro-header')
  <!-- Header -->
  <header class="intro-header text-white" style="background: url('{{ asset
 
('images/contact-bg.jpg') }}') no-repeat center center;">
    <div class="container text-center">
      <h1>UTS Web-Lanjut</h1>
      <p class="lead">SOAL SOAL UTS</p>
    </div>
  </header>
  <!-- END : Header -->

 
@section('content')
<!-- Main -->
<body class="intro-header text-white" style="background: url('{{ asset
 
 ('images/home-bg.jpg') }}') no-repeat center center;">
  <section class="main">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>UTS Web-Lanjut</h2>
          <p class="lead">buat 5 link <br> buat form validasi <br> upload ke github.</p>
        </div>
      </div>
    </div>
  </section>
@endsection